$i = 999999
do {
    Write-Host $i
    Sleep 60
    $i--
} while ($i -gt 0)
